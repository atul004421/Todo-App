# TaskFlow — React Native To-Do App with Authentication

A full-stack To-Do app built for the assignment: a **React Native (TypeScript) CLI app for Android**
backed by a **Node.js + Express + MongoDB** REST API, with JWT-based authentication, Redux Toolkit
state management, and a custom priority/deadline sorting algorithm.

```
todo-app/
├── backend/     Node.js + Express + MongoDB API (TypeScript)
└── frontend/    React Native CLI app source (TypeScript) — drop into a scaffolded RN project
```

## Features

- **Auth**: register / login with email + password, JWT issued by the backend and stored in
  AsyncStorage, protected routes on both ends.
- **Tasks**: create, edit, delete, mark complete — each with title, description, scheduled
  date-time, deadline, priority (low/medium/high) and optional tags.
- **State management**: Redux Toolkit (`authSlice`, `taskSlice`) with async thunks for every
  API call, so screens just `useAppSelector`/`useAppDispatch`.
- **Smart sorting (bonus)**: `getUrgencyScore()` (implemented identically on both the client
  and the server) blends three signals into one score — how close the deadline is, priority
  weight, and whether it's already overdue — so the most urgent, highest-priority tasks always
  float to the top, and completed tasks sink to the bottom.
- **Filtering (bonus)**: filter chips for priority (all/high/medium/low) and a "done" toggle.
- **Tags/categories (bonus)**: comma-separated tags per task, shown as chips.
- **UI**: dark, modern theme (`src/theme/colors.ts`) with a floating action button, priority
  badges, live countdown/overdue labels, and pull-to-refresh.

## Backend setup

```bash
cd backend
cp .env.example .env      # edit MONGO_URI / JWT_SECRET if needed
npm install
npm run dev                # starts on http://localhost:5000
```

Requires a running MongoDB instance (local `mongod`, or a free MongoDB Atlas cluster —
just paste its connection string into `MONGO_URI`).

**API summary**

| Method | Route                  | Auth | Description               |
|--------|-------------------------|------|---------------------------|
| POST   | /api/auth/register       | –    | Create an account         |
| POST   | /api/auth/login          | –    | Log in, returns a JWT     |
| GET    | /api/tasks                | ✓    | List tasks (filter/sort via query params) |
| POST   | /api/tasks                | ✓    | Create a task              |
| PATCH  | /api/tasks/:id             | ✓    | Update a task              |
| PATCH  | /api/tasks/:id/toggle       | ✓    | Toggle completed            |
| DELETE | /api/tasks/:id             | ✓    | Delete a task               |

## Frontend setup

The `frontend/` folder contains the app's **source code** (`App.tsx`, `src/`, `package.json`,
`tsconfig.json`). React Native CLI projects also need generated native `android/`/`ios`
folders, which aren't hand-written — scaffold them once with the CLI, then drop this source in:

```bash
npx @react-native-community/cli init TodoApp --template react-native-template-typescript
cd TodoApp

# copy this project's source over the generated skeleton
cp -r <path-to>/frontend/src ./src
cp <path-to>/frontend/App.tsx ./App.tsx

# merge the "dependencies"/"devDependencies" from frontend/package.json into
# the generated package.json, then:
npm install

# point the API base URL at your backend if it's not on 10.0.2.2:5000
# (edit src/api/client.ts)

npx react-native run-android
```

Notes:
- `src/api/client.ts` uses `10.0.2.2` — the Android emulator's alias for your machine's
  `localhost`. If you're testing on a physical device, replace it with your machine's LAN IP
  (and make sure the backend's `cors()` and firewall allow it).
- Date/time pickers use `@react-native-community/datetimepicker`, which autolinks with RN CLI.

## Design notes

- **Auth flow**: `AppNavigator` switches between the Auth stack (Login/Register) and the App
  stack (TaskList/AddEditTask) purely based on whether a JWT is present in Redux state, restored
  from AsyncStorage on launch via `restoreSession()`.
- **Why Redux Toolkit over plain Context**: two independent, growing pieces of async state
  (auth + tasks) with several mutations each (add/edit/toggle/delete) map cleanly onto slices
  and thunks, and it keeps components free of manual loading/error boilerplate.
- **Sorting algorithm** (`src/utils/sortTasks.ts` on the frontend, `src/utils/sortTasks.ts` on
  the backend — kept identical so client-side re-sorts after a mutation match what a fresh
  fetch would return):
  - Completed tasks always sort last.
  - Overdue tasks always outrank non-overdue ones, more-overdue-and-higher-priority first.
  - Otherwise, urgency rises as the deadline approaches within a one-week horizon, scaled by
    a priority weight (high=3, medium=2, low=1) — so a high-priority task due in 2 hours beats
    a low-priority task due in 1 hour, but a low-priority task due in 10 minutes still beats a
    high-priority task due in 6 days.

## What's intentionally left out

- Push notifications / reminders for approaching deadlines — noted as a natural next feature.
- Password reset / email verification flows — out of scope for a fresher assignment, but the
  backend's auth controller is where they'd be added.
- Automated tests — kept out to keep the submission focused on the required functionality.
