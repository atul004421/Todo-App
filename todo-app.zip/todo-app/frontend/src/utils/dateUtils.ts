// Formats an ISO date string as a short, readable label, e.g. "24 Sep, 6:30 PM"
export function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    day: '2-digit',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
  });
}

// Human-readable countdown/overdue label for a deadline
export function formatCountdown(iso: string): { label: string; overdue: boolean } {
  const diffMs = new Date(iso).getTime() - Date.now();
  const overdue = diffMs < 0;
  const abs = Math.abs(diffMs);

  const hours = Math.floor(abs / 36e5);
  const days = Math.floor(hours / 24);

  let label: string;
  if (days > 0) label = `${days}d ${hours % 24}h`;
  else if (hours > 0) label = `${hours}h`;
  else label = `${Math.max(1, Math.floor(abs / 60000))}m`;

  return { label: overdue ? `Overdue by ${label}` : `Due in ${label}`, overdue };
}
