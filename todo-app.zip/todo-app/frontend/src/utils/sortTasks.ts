import { Task } from '../types';

const PRIORITY_WEIGHT: Record<Task['priority'], number> = { high: 3, medium: 2, low: 1 };

// Same blended urgency scoring used on the backend: soonest deadline +
// highest priority sorts first, completed tasks always sink to the bottom.
export function getUrgencyScore(task: Task): number {
  if (task.completed) return -Infinity;

  const now = Date.now();
  const hoursToDeadline = (new Date(task.deadline).getTime() - now) / 36e5;
  const weight = PRIORITY_WEIGHT[task.priority] ?? 1;

  if (hoursToDeadline < 0) {
    return 1000 + Math.min(500, Math.abs(hoursToDeadline)) + weight * 50;
  }

  const timeUrgency = Math.max(0, 168 - Math.min(hoursToDeadline, 168));
  return timeUrgency * weight;
}

export function sortTasks(tasks: Task[]): Task[] {
  return [...tasks].sort((a, b) => getUrgencyScore(b) - getUrgencyScore(a));
}
