import React, { useState } from 'react';
import {
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../types';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { register } from '../store/authSlice';
import CustomInput from '../components/CustomInput';
import CustomButton from '../components/CustomButton';
import { colors } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Register'>;

export default function RegisterScreen({ navigation }: Props) {
  const dispatch = useAppDispatch();
  const { status, error } = useAppSelector((s) => s.auth);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [touched, setTouched] = useState(false);

  const emailValid = /\S+@\S+\.\S+/.test(email);
  const passwordValid = password.length >= 6;
  const confirmValid = confirm === password && confirm.length > 0;
  const canSubmit = emailValid && passwordValid && confirmValid;

  const handleRegister = () => {
    setTouched(true);
    if (!canSubmit) return;
    dispatch(register({ email, password }));
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <Text style={styles.logo}>✓ TaskFlow</Text>
        <Text style={styles.title}>Create your account</Text>
        <Text style={styles.subtitle}>Start organizing your tasks in minutes</Text>

        <CustomInput
          label="Email"
          placeholder="you@example.com"
          autoCapitalize="none"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          error={touched && !emailValid ? 'Enter a valid email' : undefined}
        />
        <CustomInput
          label="Password"
          placeholder="••••••••"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          error={touched && !passwordValid ? 'At least 6 characters' : undefined}
        />
        <CustomInput
          label="Confirm password"
          placeholder="••••••••"
          secureTextEntry
          value={confirm}
          onChangeText={setConfirm}
          error={touched && !confirmValid ? 'Passwords do not match' : undefined}
        />

        {error ? <Text style={styles.serverError}>{error}</Text> : null}

        <CustomButton title="Sign Up" onPress={handleRegister} loading={status === 'loading'} />

        <TouchableOpacity style={styles.footer} onPress={() => navigation.navigate('Login')}>
          <Text style={styles.footerText}>
            Already have an account? <Text style={styles.footerLink}>Log in</Text>
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  logo: { color: colors.accent, fontSize: 18, fontWeight: '800', marginBottom: 24 },
  title: { color: colors.text, fontSize: 28, fontWeight: '800', marginBottom: 6 },
  subtitle: { color: colors.textMuted, fontSize: 14, marginBottom: 28 },
  serverError: { color: colors.danger, marginBottom: 12, textAlign: 'center' },
  footer: { marginTop: 20, alignItems: 'center' },
  footerText: { color: colors.textMuted },
  footerLink: { color: colors.primary, fontWeight: '700' },
});
