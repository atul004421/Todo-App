import React, { useEffect, useCallback, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList, Priority } from '../types';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import {
  fetchTasks,
  toggleTask,
  removeTask,
  setPriorityFilter,
  setCompletedFilter,
} from '../store/taskSlice';
import { logout } from '../store/authSlice';
import TaskItem from '../components/TaskItem';
import { colors } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'TaskList'>;

const PRIORITY_FILTERS: (Priority | 'all')[] = ['all', 'high', 'medium', 'low'];

export default function TaskListScreen({ navigation }: Props) {
  const dispatch = useAppDispatch();
  const { items, status, filter } = useAppSelector((s) => s.tasks);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(() => {
    dispatch(fetchTasks());
  }, [dispatch]);

  useEffect(() => {
    load();
  }, [load]);

  const onRefresh = async () => {
    setRefreshing(true);
    await dispatch(fetchTasks());
    setRefreshing(false);
  };

  const visibleTasks = items.filter((t) => {
    if (filter.priority && t.priority !== filter.priority) return false;
    if (filter.completed !== undefined && t.completed !== filter.completed) return false;
    return true;
  });

  const pendingCount = items.filter((t) => !t.completed).length;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>My Tasks</Text>
          <Text style={styles.subtitle}>{pendingCount} pending</Text>
        </View>
        <TouchableOpacity onPress={() => dispatch(logout())}>
          <Text style={styles.logout}>Log out</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.filterRow}>
        {PRIORITY_FILTERS.map((p) => {
          const active = p === 'all' ? !filter.priority : filter.priority === p;
          return (
            <TouchableOpacity
              key={p}
              style={[styles.filterChip, active && styles.filterChipActive]}
              onPress={() => dispatch(setPriorityFilter(p === 'all' ? undefined : p))}
            >
              <Text style={[styles.filterText, active && styles.filterTextActive]}>
                {p.toUpperCase()}
              </Text>
            </TouchableOpacity>
          );
        })}
        <TouchableOpacity
          style={[styles.filterChip, filter.completed && styles.filterChipActive]}
          onPress={() => dispatch(setCompletedFilter(filter.completed ? undefined : true))}
        >
          <Text style={[styles.filterText, filter.completed && styles.filterTextActive]}>
            DONE
          </Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={visibleTasks}
        keyExtractor={(item) => item._id}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent} />
        }
        ListEmptyComponent={
          status !== 'loading' ? (
            <View style={styles.empty}>
              <Text style={styles.emptyText}>No tasks here yet.{'\n'}Tap + to add one.</Text>
            </View>
          ) : null
        }
        renderItem={({ item }) => (
          <TaskItem
            task={item}
            onToggle={() => dispatch(toggleTask(item._id))}
            onDelete={() => dispatch(removeTask(item._id))}
            onPress={() => navigation.navigate('AddEditTask', { taskId: item._id })}
          />
        )}
      />

      <TouchableOpacity style={styles.fab} onPress={() => navigation.navigate('AddEditTask')}>
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, paddingTop: 60 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  title: { color: colors.text, fontSize: 26, fontWeight: '800' },
  subtitle: { color: colors.textMuted, fontSize: 13, marginTop: 2 },
  logout: { color: colors.danger, fontWeight: '600' },
  filterRow: { flexDirection: 'row', paddingHorizontal: 20, marginBottom: 12, flexWrap: 'wrap' },
  filterChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: colors.surfaceAlt,
    marginRight: 8,
    marginBottom: 8,
  },
  filterChipActive: { backgroundColor: colors.primary },
  filterText: { color: colors.textMuted, fontSize: 11, fontWeight: '700' },
  filterTextActive: { color: '#fff' },
  list: { paddingHorizontal: 20, paddingBottom: 100 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyText: { color: colors.textMuted, textAlign: 'center', fontSize: 14, lineHeight: 22 },
  fab: {
    position: 'absolute',
    right: 24,
    bottom: 32,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOpacity: 0.5,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  fabText: { color: '#fff', fontSize: 30, fontWeight: '300', marginTop: -2 },
});
