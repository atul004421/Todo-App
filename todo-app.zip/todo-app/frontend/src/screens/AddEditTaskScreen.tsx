import React, { useState, useMemo } from 'react';
import { Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from 'react-native';
import DateTimePicker, { DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList, Priority } from '../types';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { addTask, editTask } from '../store/taskSlice';
import CustomInput from '../components/CustomInput';
import CustomButton from '../components/CustomButton';
import { colors, priorityColors } from '../theme/colors';
import { formatDateTime } from '../utils/dateUtils';

type Props = NativeStackScreenProps<RootStackParamList, 'AddEditTask'>;

const PRIORITIES: Priority[] = ['low', 'medium', 'high'];

export default function AddEditTaskScreen({ navigation, route }: Props) {
  const dispatch = useAppDispatch();
  const taskId = route.params?.taskId;
  const existing = useAppSelector((s) => s.tasks.items.find((t) => t._id === taskId));

  const [title, setTitle] = useState(existing?.title ?? '');
  const [description, setDescription] = useState(existing?.description ?? '');
  const [priority, setPriority] = useState<Priority>(existing?.priority ?? 'medium');
  const [tagsInput, setTagsInput] = useState(existing?.tags.join(', ') ?? '');
  const [dateTime, setDateTime] = useState(existing ? new Date(existing.dateTime) : new Date());
  const [deadline, setDeadline] = useState(
    existing ? new Date(existing.deadline) : new Date(Date.now() + 24 * 36e5)
  );
  const [showDatePicker, setShowDatePicker] = useState<'dateTime' | 'deadline' | null>(null);
  const [saving, setSaving] = useState(false);
  const [titleTouched, setTitleTouched] = useState(false);

  const titleValid = title.trim().length > 0;

  const tags = useMemo(
    () => tagsInput.split(',').map((t) => t.trim()).filter(Boolean),
    [tagsInput]
  );

  const handlePickerChange = (field: 'dateTime' | 'deadline') => (
    _event: DateTimePickerEvent,
    selected?: Date
  ) => {
    setShowDatePicker(Platform.OS === 'ios' ? showDatePicker : null);
    if (!selected) return;
    if (field === 'dateTime') setDateTime(selected);
    else setDeadline(selected);
  };

  const handleSave = async () => {
    setTitleTouched(true);
    if (!titleValid) return;

    setSaving(true);
    const payload = {
      title: title.trim(),
      description,
      priority,
      tags,
      dateTime: dateTime.toISOString(),
      deadline: deadline.toISOString(),
    };

    if (taskId) {
      await dispatch(editTask({ id: taskId, changes: payload }));
    } else {
      await dispatch(addTask(payload));
    }
    setSaving(false);
    navigation.goBack();
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>{taskId ? 'Edit Task' : 'New Task'}</Text>

      <CustomInput
        label="Title"
        placeholder="e.g. Finish assignment report"
        value={title}
        onChangeText={setTitle}
        error={titleTouched && !titleValid ? 'Title is required' : undefined}
      />
      <CustomInput
        label="Description"
        placeholder="Add any notes..."
        value={description}
        onChangeText={setDescription}
        multiline
        numberOfLines={3}
        style={styles.textArea}
      />
      <CustomInput
        label="Tags (comma separated)"
        placeholder="work, urgent"
        value={tagsInput}
        onChangeText={setTagsInput}
      />

      <Text style={styles.label}>Priority</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.priorityRow}>
        {PRIORITIES.map((p) => {
          const active = priority === p;
          return (
            <TouchableOpacity
              key={p}
              style={[
                styles.priorityChip,
                { borderColor: priorityColors[p] },
                active && { backgroundColor: priorityColors[p] },
              ]}
              onPress={() => setPriority(p)}
            >
              <Text
                style={[
                  styles.priorityChipText,
                  { color: active ? '#0F1226' : priorityColors[p] },
                ]}
              >
                {p.toUpperCase()}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <Text style={styles.label}>Scheduled for</Text>
      <TouchableOpacity style={styles.dateButton} onPress={() => setShowDatePicker('dateTime')}>
        <Text style={styles.dateButtonText}>{formatDateTime(dateTime.toISOString())}</Text>
      </TouchableOpacity>

      <Text style={styles.label}>Deadline</Text>
      <TouchableOpacity style={styles.dateButton} onPress={() => setShowDatePicker('deadline')}>
        <Text style={styles.dateButtonText}>{formatDateTime(deadline.toISOString())}</Text>
      </TouchableOpacity>

      {showDatePicker && (
        <DateTimePicker
          value={showDatePicker === 'dateTime' ? dateTime : deadline}
          mode="datetime"
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={handlePickerChange(showDatePicker)}
        />
      )}

      <CustomButton
        title={taskId ? 'Save Changes' : 'Add Task'}
        onPress={handleSave}
        loading={saving}
        style={styles.saveButton}
      />
      <CustomButton
        title="Cancel"
        variant="outline"
        onPress={() => navigation.goBack()}
        style={styles.cancelButton}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: 24, paddingTop: 60, paddingBottom: 60 },
  title: { color: colors.text, fontSize: 24, fontWeight: '800', marginBottom: 24 },
  label: { color: colors.textMuted, fontSize: 13, fontWeight: '600', marginBottom: 8 },
  textArea: { minHeight: 80, textAlignVertical: 'top' },
  priorityRow: { marginBottom: 20 },
  priorityChip: {
    borderWidth: 1.5,
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 14,
    marginRight: 10,
  },
  priorityChipText: { fontWeight: '700', fontSize: 12 },
  dateButton: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: 12,
    padding: 14,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: colors.border,
  },
  dateButtonText: { color: colors.text, fontSize: 14, fontWeight: '600' },
  saveButton: { marginTop: 12 },
  cancelButton: { marginTop: 12 },
});
