import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AuthState, User } from '../types';
import { loginRequest, registerRequest } from '../api/authApi';

const initialState: AuthState = {
  token: null,
  user: null,
  status: 'idle',
  error: null,
};

interface AuthResponse {
  token: string;
  user: User;
}

export const login = createAsyncThunk<AuthResponse, { email: string; password: string }>(
  'auth/login',
  async ({ email, password }) => {
    const data = await loginRequest(email, password);
    await AsyncStorage.setItem('token', data.token);
    return data;
  }
);

export const register = createAsyncThunk<AuthResponse, { email: string; password: string }>(
  'auth/register',
  async ({ email, password }) => {
    const data = await registerRequest(email, password);
    await AsyncStorage.setItem('token', data.token);
    return data;
  }
);

export const restoreSession = createAsyncThunk('auth/restore', async () => {
  const token = await AsyncStorage.getItem('token');
  return token;
});

export const logout = createAsyncThunk('auth/logout', async () => {
  await AsyncStorage.removeItem('token');
});

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(login.fulfilled, (state, action: PayloadAction<AuthResponse>) => {
        state.status = 'idle';
        state.token = action.payload.token;
        state.user = action.payload.user;
      })
      .addCase(login.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || 'Login failed';
      })
      .addCase(register.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(register.fulfilled, (state, action: PayloadAction<AuthResponse>) => {
        state.status = 'idle';
        state.token = action.payload.token;
        state.user = action.payload.user;
      })
      .addCase(register.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || 'Registration failed';
      })
      .addCase(restoreSession.fulfilled, (state, action) => {
        state.token = action.payload;
      })
      .addCase(logout.fulfilled, (state) => {
        state.token = null;
        state.user = null;
      });
  },
});

export default authSlice.reducer;
