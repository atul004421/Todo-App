import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { Task, TaskState } from '../types';
import {
  fetchTasksRequest,
  createTaskRequest,
  updateTaskRequest,
  toggleTaskRequest,
  deleteTaskRequest,
} from '../api/taskApi';
import { sortTasks } from '../utils/sortTasks';

const initialState: TaskState = {
  items: [],
  status: 'idle',
  error: null,
  filter: {},
};

export const fetchTasks = createAsyncThunk('tasks/fetch', fetchTasksRequest);

export const addTask = createAsyncThunk('tasks/add', (task: Partial<Task>) =>
  createTaskRequest(task)
);

export const editTask = createAsyncThunk(
  'tasks/edit',
  ({ id, changes }: { id: string; changes: Partial<Task> }) => updateTaskRequest(id, changes)
);

export const toggleTask = createAsyncThunk('tasks/toggle', (id: string) =>
  toggleTaskRequest(id)
);

export const removeTask = createAsyncThunk('tasks/remove', async (id: string) => {
  await deleteTaskRequest(id);
  return id;
});

const taskSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    setPriorityFilter(state, action: PayloadAction<Task['priority'] | undefined>) {
      state.filter.priority = action.payload;
    },
    setCompletedFilter(state, action: PayloadAction<boolean | undefined>) {
      state.filter.completed = action.payload;
    },
    clearTasks(state) {
      state.items = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTasks.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchTasks.fulfilled, (state, action: PayloadAction<Task[]>) => {
        state.status = 'idle';
        state.items = sortTasks(action.payload);
      })
      .addCase(fetchTasks.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message || 'Failed to load tasks';
      })
      .addCase(addTask.fulfilled, (state, action: PayloadAction<Task>) => {
        state.items = sortTasks([...state.items, action.payload]);
      })
      .addCase(editTask.fulfilled, (state, action: PayloadAction<Task>) => {
        const idx = state.items.findIndex((t) => t._id === action.payload._id);
        if (idx !== -1) state.items[idx] = action.payload;
        state.items = sortTasks(state.items);
      })
      .addCase(toggleTask.fulfilled, (state, action: PayloadAction<Task>) => {
        const idx = state.items.findIndex((t) => t._id === action.payload._id);
        if (idx !== -1) state.items[idx] = action.payload;
        state.items = sortTasks(state.items);
      })
      .addCase(removeTask.fulfilled, (state, action: PayloadAction<string>) => {
        state.items = state.items.filter((t) => t._id !== action.payload);
      });
  },
});

export const { setPriorityFilter, setCompletedFilter, clearTasks } = taskSlice.actions;
export default taskSlice.reducer;
