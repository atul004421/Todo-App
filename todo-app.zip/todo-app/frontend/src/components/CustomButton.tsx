import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, ViewStyle } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  title: string;
  onPress: () => void;
  loading?: boolean;
  variant?: 'primary' | 'outline' | 'danger';
  style?: ViewStyle;
  disabled?: boolean;
}

export default function CustomButton({
  title,
  onPress,
  loading,
  variant = 'primary',
  style,
  disabled,
}: Props) {
  const variantStyle =
    variant === 'outline' ? styles.outline : variant === 'danger' ? styles.danger : styles.primary;
  const textStyle = variant === 'outline' ? styles.outlineText : styles.text;

  return (
    <TouchableOpacity
      style={[styles.base, variantStyle, style, disabled ? styles.disabled : null]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading ? (
        <ActivityIndicator color={variant === 'outline' ? colors.primary : '#fff'} />
      ) : (
        <Text style={textStyle}>{title}</Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  base: {
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primary: { backgroundColor: colors.primary },
  danger: { backgroundColor: colors.danger },
  outline: { backgroundColor: 'transparent', borderWidth: 1.5, borderColor: colors.primary },
  disabled: { opacity: 0.5 },
  text: { color: '#fff', fontWeight: '700', fontSize: 15 },
  outlineText: { color: colors.primary, fontWeight: '700', fontSize: 15 },
});
