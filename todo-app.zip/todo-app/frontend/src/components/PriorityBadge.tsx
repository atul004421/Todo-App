import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Priority } from '../types';
import { priorityColors } from '../theme/colors';

export default function PriorityBadge({ priority }: { priority: Priority }) {
  return (
    <View style={[styles.badge, { backgroundColor: `${priorityColors[priority]}33` }]}>
      <View style={[styles.dot, { backgroundColor: priorityColors[priority] }]} />
      <Text style={[styles.text, { color: priorityColors[priority] }]}>
        {priority.toUpperCase()}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  dot: { width: 6, height: 6, borderRadius: 3, marginRight: 6 },
  text: { fontSize: 11, fontWeight: '700' },
});
