import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Task } from '../types';
import { colors } from '../theme/colors';
import PriorityBadge from './PriorityBadge';
import { formatDateTime, formatCountdown } from '../utils/dateUtils';

interface Props {
  task: Task;
  onToggle: () => void;
  onDelete: () => void;
  onPress: () => void;
}

export default function TaskItem({ task, onToggle, onDelete, onPress }: Props) {
  const countdown = formatCountdown(task.deadline);

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.85}>
      <TouchableOpacity style={styles.checkbox} onPress={onToggle}>
        <View style={[styles.checkboxInner, task.completed && styles.checkboxChecked]}>
          {task.completed && <Text style={styles.checkmark}>✓</Text>}
        </View>
      </TouchableOpacity>

      <View style={styles.content}>
        <Text style={[styles.title, task.completed && styles.titleDone]} numberOfLines={1}>
          {task.title}
        </Text>
        {task.description ? (
          <Text style={styles.description} numberOfLines={2}>
            {task.description}
          </Text>
        ) : null}

        <View style={styles.metaRow}>
          <PriorityBadge priority={task.priority} />
          <Text style={styles.scheduled}>{formatDateTime(task.dateTime)}</Text>
        </View>

        {!task.completed && (
          <Text style={[styles.countdown, countdown.overdue && styles.overdue]}>
            {countdown.label}
          </Text>
        )}

        {task.tags.length > 0 && (
          <View style={styles.tagRow}>
            {task.tags.map((tag) => (
              <View key={tag} style={styles.tagChip}>
                <Text style={styles.tagText}>#{tag}</Text>
              </View>
            ))}
          </View>
        )}
      </View>

      <TouchableOpacity style={styles.deleteBtn} onPress={onDelete}>
        <Text style={styles.deleteText}>🗑</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 14,
    marginBottom: 12,
    alignItems: 'flex-start',
    borderWidth: 1,
    borderColor: colors.border,
  },
  checkbox: { marginRight: 12, marginTop: 2 },
  checkboxInner: {
    width: 24,
    height: 24,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: { backgroundColor: colors.primary },
  checkmark: { color: '#fff', fontSize: 14, fontWeight: '700' },
  content: { flex: 1 },
  title: { color: colors.text, fontSize: 16, fontWeight: '700' },
  titleDone: { textDecorationLine: 'line-through', color: colors.textMuted },
  description: { color: colors.textMuted, fontSize: 13, marginTop: 2 },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  scheduled: { color: colors.textMuted, fontSize: 12 },
  countdown: { color: colors.accent, fontSize: 12, fontWeight: '600', marginTop: 6 },
  overdue: { color: colors.danger },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 },
  tagChip: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
    marginRight: 6,
    marginBottom: 4,
  },
  tagText: { color: colors.accent, fontSize: 11 },
  deleteBtn: { padding: 4, marginLeft: 8 },
  deleteText: { fontSize: 18 },
});
