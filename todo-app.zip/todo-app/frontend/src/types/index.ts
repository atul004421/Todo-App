export type Priority = 'low' | 'medium' | 'high';

export interface Task {
  _id: string;
  title: string;
  description: string;
  dateTime: string; // ISO string
  deadline: string; // ISO string
  priority: Priority;
  completed: boolean;
  tags: string[];
  user: string;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  email: string;
}

export interface AuthState {
  token: string | null;
  user: User | null;
  status: 'idle' | 'loading' | 'failed';
  error: string | null;
}

export interface TaskState {
  items: Task[];
  status: 'idle' | 'loading' | 'failed';
  error: string | null;
  filter: {
    completed?: boolean;
    priority?: Priority;
  };
}

export type RootStackParamList = {
  Login: undefined;
  Register: undefined;
  TaskList: undefined;
  AddEditTask: { taskId?: string } | undefined;
};
