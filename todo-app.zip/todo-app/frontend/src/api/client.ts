import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Android emulator maps 10.0.2.2 to the host machine's localhost.
// Change this to your machine's LAN IP when testing on a physical device.
export const BASE_URL = 'http://10.0.2.2:5000/api';

export const apiClient = axios.create({ baseURL: BASE_URL });

// Attach the stored JWT to every outgoing request, if present
apiClient.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
