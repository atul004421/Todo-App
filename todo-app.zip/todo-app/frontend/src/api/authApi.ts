import { apiClient } from './client';

export const registerRequest = (email: string, password: string) =>
  apiClient.post('/auth/register', { email, password }).then((r) => r.data);

export const loginRequest = (email: string, password: string) =>
  apiClient.post('/auth/login', { email, password }).then((r) => r.data);
