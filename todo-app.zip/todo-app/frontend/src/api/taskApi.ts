import { apiClient } from './client';
import { Task } from '../types';

export const fetchTasksRequest = () =>
  apiClient.get<Task[]>('/tasks').then((r) => r.data);

export const createTaskRequest = (task: Partial<Task>) =>
  apiClient.post<Task>('/tasks', task).then((r) => r.data);

export const updateTaskRequest = (id: string, task: Partial<Task>) =>
  apiClient.patch<Task>(`/tasks/${id}`, task).then((r) => r.data);

export const toggleTaskRequest = (id: string) =>
  apiClient.patch<Task>(`/tasks/${id}/toggle`).then((r) => r.data);

export const deleteTaskRequest = (id: string) =>
  apiClient.delete(`/tasks/${id}`).then((r) => r.data);
