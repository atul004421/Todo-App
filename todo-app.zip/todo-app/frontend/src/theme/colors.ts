// Central palette for the app. Keeping colors here makes the "cool, creative"
// UI consistent and easy to re-theme.
export const colors = {
  background: '#0F1226',
  surface: '#1B1F3B',
  surfaceAlt: '#252A4A',
  primary: '#7C5CFC',
  primaryDark: '#5B3FE0',
  accent: '#37E8C6',
  text: '#F5F6FA',
  textMuted: '#9AA0C3',
  danger: '#FF5C7A',
  success: '#3DDC97',
  warning: '#FFC15E',
  border: '#2E335C',
};

export const priorityColors: Record<'low' | 'medium' | 'high', string> = {
  low: colors.success,
  medium: colors.warning,
  high: colors.danger,
};
