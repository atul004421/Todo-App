import { Schema, model, Document, Types } from 'mongoose';

export type Priority = 'low' | 'medium' | 'high';

export interface ITask extends Document {
  title: string;
  description: string;
  dateTime: Date; // when the task is scheduled/planned for
  deadline: Date; // hard deadline for the task
  priority: Priority;
  completed: boolean;
  tags: string[];
  user: Types.ObjectId; // owning user
  createdAt: Date;
  updatedAt: Date;
}

const taskSchema = new Schema<ITask>(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: '' },
    dateTime: { type: Date, required: true },
    deadline: { type: Date, required: true },
    priority: {
      type: String,
      enum: ['low', 'medium', 'high'],
      default: 'medium',
    },
    completed: { type: Boolean, default: false },
    tags: { type: [String], default: [] },
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  },
  { timestamps: true }
);

export default model<ITask>('Task', taskSchema);
