import { Schema, model, Document } from 'mongoose';

// Shape of a User document, used for typing throughout the app
export interface IUser extends Document {
  email: string;
  password: string; // stored as a bcrypt hash, never plain text
  createdAt: Date;
}

const userSchema = new Schema<IUser>(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
  },
  { timestamps: true }
);

export default model<IUser>('User', userSchema);
