import { ITask } from '../models/Task';

// Weight given to each priority level when computing urgency
const PRIORITY_WEIGHT: Record<string, number> = { high: 3, medium: 2, low: 1 };

/**
 * Produces a single urgency score for a task that blends three signals:
 *  - how close (or overdue) the deadline is
 *  - the task's priority
 *  - completed tasks are always pushed to the bottom
 * Higher score = should be shown first.
 */
export function getUrgencyScore(task: ITask): number {
  if (task.completed) return -Infinity;

  const now = Date.now();
  const hoursToDeadline = (new Date(task.deadline).getTime() - now) / 36e5;
  const weight = PRIORITY_WEIGHT[task.priority] ?? 1;

  if (hoursToDeadline < 0) {
    // Overdue: the more overdue + the higher priority, the more urgent
    return 1000 + Math.min(500, Math.abs(hoursToDeadline)) + weight * 50;
  }

  // Not yet due: urgency rises as the deadline approaches, scaled by priority.
  // A 168-hour (1 week) horizon keeps far-off tasks from dominating the score.
  const timeUrgency = Math.max(0, 168 - Math.min(hoursToDeadline, 168));
  return timeUrgency * weight;
}

export function sortByUrgency(tasks: ITask[]): ITask[] {
  return [...tasks].sort((a, b) => getUrgencyScore(b) - getUrgencyScore(a));
}
