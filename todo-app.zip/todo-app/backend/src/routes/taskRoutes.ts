import { Router } from 'express';
import { requireAuth } from '../middleware/auth';
import {
  getTasks,
  createTask,
  updateTask,
  toggleComplete,
  deleteTask,
} from '../controllers/taskController';

const router = Router();

// Every task route requires a valid JWT
router.use(requireAuth);

router.get('/', getTasks);
router.post('/', createTask);
router.patch('/:id', updateTask);
router.patch('/:id/toggle', toggleComplete);
router.delete('/:id', deleteTask);

export default router;
