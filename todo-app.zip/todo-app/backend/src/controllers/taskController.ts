import { Response } from 'express';
import Task, { ITask } from '../models/Task';
import { AuthRequest } from '../middleware/auth';
import { sortByUrgency } from '../utils/sortTasks';

// GET /api/tasks?completed=true&priority=high&tag=work&sort=urgency
export const getTasks = async (req: AuthRequest, res: Response) => {
  const { completed, priority, tag, sort } = req.query;

  const filter: Record<string, unknown> = { user: req.userId };
  if (completed !== undefined) filter.completed = completed === 'true';
  if (priority) filter.priority = priority;
  if (tag) filter.tags = tag;

  let tasks: ITask[] = await Task.find(filter);

  if (sort === 'urgency' || sort === undefined) {
    tasks = sortByUrgency(tasks);
  } else if (sort === 'deadline') {
    tasks = tasks.sort((a, b) => a.deadline.getTime() - b.deadline.getTime());
  } else if (sort === 'priority') {
    const order: Record<string, number> = { high: 0, medium: 1, low: 2 };
    tasks = tasks.sort((a, b) => order[a.priority] - order[b.priority]);
  }

  res.json(tasks);
};

export const createTask = async (req: AuthRequest, res: Response) => {
  try {
    const { title, description, dateTime, deadline, priority, tags } = req.body;

    if (!title || !dateTime || !deadline) {
      return res.status(400).json({ message: 'title, dateTime and deadline are required' });
    }

    const task = await Task.create({
      title,
      description,
      dateTime,
      deadline,
      priority,
      tags,
      user: req.userId,
    });

    res.status(201).json(task);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create task', error: (err as Error).message });
  }
};

export const updateTask = async (req: AuthRequest, res: Response) => {
  try {
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      req.body,
      { new: true, runValidators: true }
    );

    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json(task);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update task', error: (err as Error).message });
  }
};

export const toggleComplete = async (req: AuthRequest, res: Response) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.userId });
  if (!task) return res.status(404).json({ message: 'Task not found' });

  task.completed = !task.completed;
  await task.save();
  res.json(task);
};

export const deleteTask = async (req: AuthRequest, res: Response) => {
  const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.userId });
  if (!task) return res.status(404).json({ message: 'Task not found' });
  res.json({ message: 'Task deleted', id: req.params.id });
};
